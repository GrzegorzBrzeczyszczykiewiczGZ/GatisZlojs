import math
import random

rad=float(input('Ievadiet riņķa līnijas rādiusu:\n'))
print(rad)
cirLength=round(2*math.pi*rad,2)
cirArea=round(math.pi*rad**2,2)
print('Riņķa līnijas garums:',cirLength) #Aprēķina un noapaļo riņķa līnijas garumu
print('Riņķa līnijas laukums:',cirArea) #Aprēķina un noapaļo riņķa līnijas laukumu

cathetus1=float(input('Ievadiet taisnleņķa trijstūra pirmās katetes garumu:\n'))
cathetus2=float(input('Ievadiet taisnleņķa trijstūra otrās katetes garumu:\n'))
hypothenuse=round(math.sqrt(cathetus1**2+cathetus2**2),2) #Aprēķina un noapaļo hipotenūzas garumu
print('Taisnleņķa trijstūra hipotenūzas garums:',hypothenuse) #Aprēķina, noapaļo un izvada hipotenūzas garumu

randomNum=random.random() #Iegūst gadījuma skaitli
print('Gadījuma skaitlis no 0 - 1:',randomNum)