import sys

def checkExit(inp): #lietoju šo funkciju kodā pēc katra ievada, lai pārbaudītu, vai lietotājs grib iziet no programmas
    if str(inp) == 'stop' or str(inp) == 'exit' or str(inp) == 'beigt' or str(inp) == 'iziet':
        print('Jūs izgājāt no programmas!')
        sys.exit(0)

def checkNegative(inp):
    while float(inp) < 0:
        inp=float(input('Vērtība nedrīkst būt negatīva! Ierakstiet atkal: '))


def calculatePrice(taxiAtStation,waitingTime,nightPrice):
    totalPrice=0
    if taxiAtStation=='n':
        totalPrice+=1.25
    totalPrice+=waitingTime*0.13

passengerNum=input('Cik būs pasažieru?: ')
checkExit(passengerNum)
passengerNum=int(passengerNum)
if passengerNum<1 or passengerNum>4:
    print('Nedrīkst būt tāds skaits pasažieru, jābūt no 1 līdz 4!')
    sys.exit(0)

while True:
    userTime=input('Ievadiet laiku (ievadiet, kā veselu stundu, piem., 15:00 = 15): ')
    checkExit(userTime)
    userTime=int(userTime)
    if userTime<0 or userTime>24:
        print('Nedrīkst būt tik pulksten, jābūt no 0 līdz 24!')
        continue
    if userTime>21 or userTime<6:
        nightPrice=True
        break

while True:
    taxiAtStation=input('Vai taksometrs atrodas pie stacijas? (j/n): ')
    checkExit(taxiAtStation)
    if taxiAtStation=='j' or taxiAtStation=='n':
        break
    else:
        print('Ievadiet vienu no opcijām!')
        continue


waitingTime=input('Cik ilgi taksometram vajadzēs Jūs gaidīt? (min): ')
checkExit(waitingTime)
checkNegative(waitingTime)

