def bubbleSort(valueDict, listLen): #algoritms, kas salīdzina katru elementu ar kātru nākamo elementu
    valueList = valueDict.items()
    valueKeys = valueDict.keys()
    for i in range(listLen-1):
        for j in range(listLen-1-i):
            if valueList[j] > valueList[j+1]:
                higherValue = valueDict[valueKeys[j]]
                lowerValue = valueDict[valueKeys[j+1]]
                higherValue, lowerValue = lowerValue, higherValue
    return(valueDict)
        
def partition(values, firstIndex, lastIndex): #sadala sarakstu mazākās daļās
    valueList = values.items()
    valueKeys = values.keys()
    pivot = values[lastIndex]
    i = firstIndex - 1

    for j in range(firstIndex, lastIndex):
        if values[j] < pivot: #ja atrasts elements mazāks par izvēlēto skaitli, tas tiek apmainīts ar lielāku vērtību
            i += 1
            (values[i], values[j]) = (values[j], values[i])

    (values[i + 1], pivot) = (pivot, values[i + 1]) #apmaina vērtību ar lielāku
    return i + 1
 
def quickSort(values, firstIndex, lastIndex): #quickSort algoritms
    if firstIndex < lastIndex:
        pivot = partition(values, firstIndex, lastIndex)
        quickSort(values, 0, pivot - 1)
        quickSort(values, pivot + 1, lastIndex)

sortedCountries=sorted(countries.items(), key=lambda x:x[1])
countries=dict(sortedCountries)

listLength = int(input("Cik studentu būs?: "))
minScore = 0
maxScore = 100
studentList = {}

for i in range(listLength):
    studentName = input("Kāds ir studenta vārds?: ")
    studentScore = int(input("Kāds ir studenta rezultāts? (0 - 100): "))
    studentList[studentName] = studentScore

print(f"Pirms BubbleSort: {studentList}")
sortedBubbleList = bubbleSort(studentList, listLength)
print(sortedBubbleList)

quickSort(studentList, 0, listLength-1)
print(studentList)