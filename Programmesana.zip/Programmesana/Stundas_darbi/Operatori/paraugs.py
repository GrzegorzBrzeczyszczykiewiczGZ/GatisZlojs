#tiek realizēta decimālskaitļu ievade
#aprēķināts izteiksmes (x+y)*(x-y)//x-y rezultāts

print('Ievadiet savu vārdu: ')
vards=input()
print('Jūsu vārds ir:',vards)

print('Ievadiet decimālskaitli:')
x=float(input()) #jāveic konvertēšana, jo input() funkcija datus atgriež strg veidā
print('Ievadītais decimālskaitlis ir',x)

print('Ievadiet decimālskaitli:')
y=float(input())
print('Ievadītais decimālskaitlis ir',y)

print('Izteiksmes (x+y)*(x-y)//x-y rezultāts ir',(x+y)*(x-y)//x-y)

z=(input('Ievadiet z vērtību: '))