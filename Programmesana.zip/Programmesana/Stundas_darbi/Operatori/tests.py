#mainīgajiem a un b piešķirtas veselas skaitļa vērtības un realizēta aritmētisko darbību izpilde
a=1
b=2
print('a =',a,'b =',b)
print('Starp skaitļiem a un b:')
print('Summa ir',a+b)
print('Starpība ir',a-b)
print('lījums ir',a/b)
print('Atlikums ir',a%b)
print('Dalījums bez atlikuma ir',a//b)

#Kas ir mainīgais - 
#Inicializācija