#30 dienas Python programmēšanas valodā

vards='Gatis'
uzvards='Zlojs'
vardsUnUzvards=vards,uzvards

valsts='Latvija'
pilseta='Sigulda'
vecums=16
gads=2022
x,y=1,2
print(vards,type(vards),'\n',uzvards,type(uzvards),'\n',vardsUnUzvards,type(vardsUnUzvards),'\n',valsts,type(valsts),'\n',pilseta,type(pilseta),'\n',vecums,type(vecums),'\n',gads,type(gads),'\n',x,type(x),'\n',y,type(y))