#datu tipu iegūšana no literāļa
print(type(1))
print(type(1.1))
print(type(1.1e3))
print(type('alpha'))
print(type("beta"))
print(type(True))

#datu tipu iegūšana no konteksta
a = 123
b = a*0.1
print(type(b))
print(type(2<3))
c = input() #lietotāja ievade
print(type(c))