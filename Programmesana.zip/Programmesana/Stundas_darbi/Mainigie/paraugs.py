name='Anna'
teksts='teksts'
skaitlis=9 #skaitlis ir skaitlis, ja neatrodas pēdiņās
print(name) #rakstīt nosaukumu, kuru grib izdrukāt
kombo=name,teksts
print(kombo)
print('teksts var būt ar garumzīmēm, mainīgajiem neliec garumzīmes')

#atrast vārda garumu
vardaGarums=len(name)
print(vardaGarums)

#chained_assignment = kaskādes veida piešķiršana
a=b=c=300
print(a,b,c)

a,b=10,"Hello"
print(a,b)

# 1. uzdevums
masina='Volvo'

x=50

x,y=5,10
print(x+y)

z=x+y
print(z)
my_first_name="John"