nenodots=input('Vai Jums ir kāds laikā nenodots izdevums? (j/n): ') #paprasa lietotājam, vai viņam ir laikā nenodots izdevums
if nenodots=='j': #pārbauda, vai lietotājs nedrīkst neko izņemt
    print('Jūs nedrīkstat neko izņemt.') #izvada rezultātu
elif nenodots=='n': #pārbauda, vai lietotājs ievadīja atļautu atbildi
    pieprasits=input('Vai publikācija ir pieperasīto izdevumu sarakstā? (j/n): ') #paprasa lietotājam, vai publikācija ir pieprasīto izdevumu sarakstā
    if pieprasits=='j': #pārbauda, vai tiks izdots uz 3 dienām
        print('Izsniedz uz 3 dienām.') #izvada rezultātu
    elif pieprasits=='n': #pārbauda, vai lietotājs ievadīja atļautu atbildi
        zurnals=input('Vai publikācija ir žurnāls? (j/n): ') #paprasa lietotājam, vai publikācija ir žurnāls
        if zurnals=='j': #pārbauda, vai tiks izdots uz 10 dienām
            print('Izsniedz uz 10 dienām.') #izvada rezultātu
        elif zurnals=='n': #pārbauda, vai lietotājs ievadīja atļautu atbildi
            students=input('Vai Jūs esat students? (j/n): ') #paprasa lietotājam, vai viņš ir students
            if students=='j': #pārbauda, vai tiks izdots uz 15 dienām
                print('Izsniedz uz 15 dienām.') #izvada rezultātu
            elif students=='n': #pārbauda, vai lietotājs ievadīja atļautu atbildi
                print('Izsniedz uz 30 dienām.') #izvada rezultātu
