#1. uzdevums

x=int(input('x='))

if x<0:
    print('Kļūda!')
elif x>100:
    print('Kļūda!')
elif x>40 or x==40:
    if x>70 or x==70:
        if x>90 or x==90:
            print('10 balles')
        else:
            print('7 balles')
    else:
        print('4 balles')
else:
    print('Tests nav nokārtots')