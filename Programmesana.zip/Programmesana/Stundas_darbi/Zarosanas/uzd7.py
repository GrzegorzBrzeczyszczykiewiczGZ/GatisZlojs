x=int(input('x='))
y=int(input('y='))

if x == 3 :
    print(x+y)
else :
    print(x-y)