import random

stop='0'
while stop=='0':
    gajieni=['akmens','papīrs','šķēres']

    cilGajiens=input('Ievadiet savu gājienu (akmens/papīrs/šķēres): ')
    datGajiens=random.choice(gajieni)

    print(f'Cilvēks: {cilGajiens} vs. Dators: {datGajiens}')

    uzv='Jūs uzvarējāt!'

    if cilGajiens==datGajiens:
        print('Ir neizšķirts!')
    elif cilGajiens=='akmens' and datGajiens=='šķēres':
        print(uzv)
    elif cilGajiens=='šķēres' and datGajiens=='papīrs':
        print(uzv)
    elif cilGajiens=='papīrs' and datGajiens=='akmens':
        print(uzv)
    else:
        print('Jūs zaudējāt!')
    
    stop=input('Vai Jūs vēlaties beigt spēlēt?\nRakstiet "1", ja jā, rakstiet "0", ja nē: ')

print('Jūs beidzāt spēlēt!')