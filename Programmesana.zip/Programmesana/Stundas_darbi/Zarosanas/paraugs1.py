atb=input('Lūdzu ievadiet savu atbildi? (j/n) ')

if atb=='j': #salīdzināšana veicama ar 2 vienādības zīmēm
    print('Jūs ievadījāt "j"')
elif atb=='n':
    print('Jūs ievadījāt "n"')
else:
    print('Jūs ievadījāt ne "j", ne "n"')

tests=input('Vai šodien ir Jaungada diena? (j/n) ')

if tests=='j':
    print('Laimīgu jauno gadu!')
elif tests=='n':
    print('Bēdīgi..')
else: #pie else nosacījuma nebūs nekāda salīdzinājuma
    print('Tā nav atbilde!') #šis tiek palaists tikai tad, ja lietotājs neieraksta 'j'