#3. uzd.
x=int(input('x='))
y=int(input('y='))

a=x+y
z=a/2
print('z=',z)