import random

def bubbleSort(valueList):
    oldList = valueList
    newList = []
    unsorted = True
    while unsorted:
        for i in range(len(oldList)):
            if oldList[i] >= oldList[i+1]:
                print()
                #newList[]

listLength = 50
minNum = 1
maxNum = 50
numList = []

for i in range(listLength):
    randomNum = random.randint(minNum, maxNum)
    numList.append(randomNum)

print(f"Pirms BubbleSort: {numList}")

