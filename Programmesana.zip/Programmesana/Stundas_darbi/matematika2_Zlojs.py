print('Divciparu skaitļa ciparu summas aprēķins') #Tiek uzrakstīts tas, kam programma ir domāta

divciparuSk=int(input('Ievadiet divciparu skaitli!\n')) #No lietotāja tiek prasīts vesels divciparu skaitlis

pirmaisCip=int(divciparuSk/10) #Tiek atrasts ievadītā skaitļa pirmais cipars
otraisCip=int(divciparuSk%10) #Tiek atrasts ievadītā skaitļa otrais cipars
ciparuSumma=pirmaisCip+otraisCip #Tiek aprēķināta ievadītā skaitļa ciparu summa

print('Divciparu skaitlis =',divciparuSk) #Konsolē lietotājam informē, kas ir ievadītais divciparu skaitlis
print('Pirmais cipars: ',pirmaisCip) #Konsolē lietotājam informē, kas ir ievadītā divciparu skaitļa pirmais cipars
print('Otrais cipars: ',otraisCip) #Konsolē lietotājam informē, kas ir ievadītā divciparu skaitļa otrais cipars
print(ciparuSumma) #Konsolē tiek izprintēta ievadītā divciparu skaitļa abu ciparu summa
