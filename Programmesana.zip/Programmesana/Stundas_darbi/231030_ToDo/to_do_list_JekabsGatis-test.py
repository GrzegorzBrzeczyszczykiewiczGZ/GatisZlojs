import sys
import time

def checkExit(inp): #lietoju šo funkciju kodā pēc katra ievada, lai pārbaudītu, vai lietotājs grib iziet no programmas
    if str(inp) == 'stop' or str(inp) == 'exit' or str(inp) == 'beigt' or str(inp) == 'iziet':
        print('Jūs izgājāt no programmas!')
        sys.exit(0)
    
tasks={
    1:'Start planning your tasks!'
}

while True:
    userChoice=input('''
--------------------------------------------------
1 - valstu nosaukumi (augošs)
2 - valstu nosaukumi (dilstošs)
3 - valstu iedzīvotāju skaiti (augošs)
4 - valstu iedzīvotāju skaiti (dilstošs)
5 - pievienot jaunu valsti
6 - apskatīt visas valstis
--------------------------------------------------

: ''')

    checkExit(userChoice)

    if userChoice=='1': #uztaisa sarakstu ar valsts nosaukumiem, tos sakārto, tad pārraksta vārdnīcu alfābetiskā secībā
        taskNumber = list(tasks.keys())
        taskNumber.sort
        tasks = {name: tasks[name] for name in taskNumber}
        continue
    elif userChoice=='2': #uztaisa sarakstu ar valsts nosaukumiem, tos sakārto, tad pārraksta vārdnīcu pret alfābetisko secību
        taskNumber = list(tasks.keys())
        taskNumber.sort(reverse=True)
        tasks = {name: tasks[name] for name in taskNumber}
        continue
    elif userChoice=='3': #sakārto valstis pēc iedzīvotāja skaita (vārdnīcas vērtībām) augoši
        sortedTasks=sorted(tasks.items(), key=lambda x:x[1])
        tasks=dict(sortedTasks)
        continue
    elif userChoice=='4': #sakārto valstis pēc iedzīvotāja skaita (vārdnīcas vērtībām) dilstoši
        sortedTasks=sorted(tasks.items(), key=lambda x:x[1], reverse=True)
        tasks=dict(sortedTasks)
        continue
    elif userChoice=='5': #lietotājs var ievadīt pats valsts nosaukumu un iedzīvotāju skaitu
        name=input('Valsts nosaukums: ')
        checkExit(name)
        population=input('Iedzīvotāju skaits: ')
        checkExit(name)
        tasks[name]=int(population)
        continue
    elif userChoice=='6':
        for name in tasks:
            print(name,'-',tasks[name])
        continue
        