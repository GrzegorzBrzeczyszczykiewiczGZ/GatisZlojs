import sys
from datetime import datetime

def checkExit(inp): #lietoju šo funkciju kodā pēc katra ievada, lai pārbaudītu, vai lietotājs grib iziet no programmas
    if str(inp) == 'stop' or str(inp) == 'exit' or str(inp) == 'beigt' or str(inp) == 'iziet':
        print('Jūs izgājāt no programmas!')
        sys.exit(0)

def showTasks(dic): #visi uzdevumi un to informācija tiek parādīta lietotājam
    for num in dic:
        taskInfo = dic[num]
        print(f'\n#{num} {taskInfo[0]} (until {taskInfo[1]}) Status: {taskInfo[2]}')

def sortByNum(dic, reverseStatus): #sorts the tasks by number and displays them
    taskNumber = list(dic.keys())
    taskNumber.sort(reverse=reverseStatus)
    dic = {num: dic[num] for num in taskNumber}
    showTasks(dic)

def sortByDate(dic, reverseStatus):
    taskInfo = dic.values()
    taskDates = []
    for task in taskInfo:
        taskDates.append(task[1])
    taskDates.sort(reverse=reverseStatus)
    print(taskDates)
    num = 0
    for date in taskDates:
        num += 1

def checkTaskAmount(dic): #checks the amount of tasks already registered, returns the amount of tasks as an integer
    taskNumber = list(dic.keys())
    taskAmount = 0
    for num in taskNumber:
        taskAmount += 1
    return taskAmount

todayDatetime = datetime.now()
todayDate = todayDatetime.strftime('%Y.%m.%d')

tasks={
    1:['Start planning your tasks!',todayDate,'✔']
}

while True:
    userChoice=input('''
--------------------------------------------------
1 - uzdevuma numurs (augošs)
2 - uzdevuma numurs (dilstošs)
3 - termiņš (augošs)
4 - termiņš (dilstošs)
5 - pievienot jaunu uzdevumu
6 - noņemt uzdevumu
7 - apskatīt visus uzdevumus
8 - mainīt darba statusu (izpildīt)
9 - eksportēt kā .txt datni
--------------------------------------------------

: ''')
    
    checkExit(userChoice)

    if userChoice == '1':
        sortByNum(tasks, False)
        continue
    if userChoice == '2':
        sortByNum(tasks, True)
        continue
    if userChoice == '3':
        sortByDate(tasks, False)
        continue
    if userChoice == '4':
        sortByDate(tasks, True)
        continue
    if userChoice == '5':
        num = checkTaskAmount(tasks) + 1
        desc=input('Uzdevuma apraksts: ')
        checkExit(desc)
        date = input('Ievadiet termiņu (YYYY.MM.DD): ')
        checkExit(date)
        tasks[num]=[desc, date, '✘']
        showTasks(tasks)
        continue
    if userChoice == '6':
        num = input('Ierakstiet uzdevuma kārtas numuru: ')
        checkExit(num)
        del tasks[int(num)]
        showTasks(tasks)
        continue
    if userChoice == '7':
        showTasks(tasks)
        continue
    if userChoice == '8':
        num = input('Ierakstiet, kuru uzdevumu Jūs izpildījāt: ')
        checkExit(num)
        tasks[int(num)][2] = '✔'
        showTasks(tasks)
        continue
    if userChoice == '9':

        continue