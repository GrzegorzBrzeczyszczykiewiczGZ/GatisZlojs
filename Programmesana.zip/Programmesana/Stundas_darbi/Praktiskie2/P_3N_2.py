import math
import random

a=int(input('Ievadiet veselu skaitli a:\n'))
b=float(input('Ievadiet realu skaitli b:\n'))

print(f'Skaitļa {a} absoluta vertiba ir', round(abs(a),1))
print(f'Skaitļa {b} noapalota vertiba ir', round(b))
print(f'Skaitļa {a} pakape 2 ir', round(a**2,1))
print(f'Skaitļa {b} kvadratsakne ir', math.sqrt(b))

randomNum=random.random()
print('Pirmais gadijuma skaitlis ir', randomNum)
randomNum=random.random()
print('Otrais gadijuma skaitlis ir', round(randomNum,6))
randomNum=random.uniform(10,11)
print('Gadijuma skaitlis intervala 10 lidz 11 ir', round(randomNum,3))

print('PI vertiba ir:', math.pi)
print('PI vertiba ir:', round(math.pi,2))