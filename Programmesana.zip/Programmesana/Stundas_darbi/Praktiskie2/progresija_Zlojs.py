print('Aritmetiskas progresijas elementu aprekins')

startNum=int(input('Ievadiet pirmo locekli!\n'))
diff=int(input('Ievadiet diferenci!\n'))
element=int(input('Ievadiet elementu skaitu!\n'))

loc=1
res=startNum
while loc <=element:
    print(f'{loc}. loceklis:    ',float(res))
    loc+=1
    res+=diff