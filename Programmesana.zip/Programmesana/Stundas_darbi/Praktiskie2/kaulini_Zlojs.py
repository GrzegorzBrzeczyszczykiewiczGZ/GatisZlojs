print('Metamā kauliņa mešanas sacensības')
name1=input('Ievadiet pirmā spēlētāja vārdu: ')
name2=input('Ievadiet otrā spēlētāja vārdu: ')
throwNum=int(input('Ievadiet metienu skaitu: '))

i=0
res1=0
res2=0

while i<throwNum:
    i+=1
    throw1=int(input(f'Ievadiet spēlētāja {name1} {i}. metiena rezultātu: '))
    throw2=int(input(f'Ievadiet spēlētāja {name2} {i}. metiena rezultātu: '))

    res1+=throw1
    res2+=throw2

print(f'Spēlētāja {name1} punktu summa: {res1}')
print(f'Spēlētāja {name2} punktu summa: {res2}')

if res1>res2:
    print('Uzvar',name1)
elif res2>res1:
    print('Uzvar',name2)
else:
    print('Neizšķirts!')