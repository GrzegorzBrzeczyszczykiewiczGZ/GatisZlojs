import sys
import math

def checkExit(inp): #lietoju šo funkciju kodā pēc katra ievada, lai pārbaudītu, vai lietotājs grib iziet no programmas
    if str(inp) == 'stop' or str(inp) == 'exit' or str(inp) == 'beigt' or str(inp) == 'iziet':
        print('Jūs izgājāt no programmas!')
        sys.exit(0)

pricePerSquareMeter=input('Ievadiet linoleja cenu kvadrātmetram (€): ')
checkExit(pricePerSquareMeter)
pricePerSquareMeter=float(pricePerSquareMeter)

roomWidth=input('Ievadiet telpas platumu (m): ')
roomWidth=float(roomWidth)
roomLength=input('Ievadiet telpas garumu (m): ')
roomLength=float(roomLength)

linoleumWidth=input('Ievadiet linoleja platumu (m): ')
checkExit(linoleumWidth)
linoleumWidth=float(linoleumWidth)
linoleumArea=roomLength*roomWidth #aprēķina linoleja daudzumu, ko vajag telpai

linoleumNum=math.ceil(roomWidth/linoleumWidth)
requiredLinoleumArea=linoleumNum*linoleumArea #aprēķina linoleja laukumu, ko vajadzēs nopirkt
price=round(requiredLinoleumArea*pricePerSquareMeter,2)

print('\nTelpai vajadzēs',linoleumArea,'m^2 linoleja.')
print('Jums šis izmaksās',str(price)+'€')
print('Būs jānopērk',str(linoleumNum),'ruļļi.')
if roomWidth%linoleumWidth!=0:
    print('Paliks pāri',str((linoleumWidth-(roomWidth%linoleumWidth))),'m plats linoleja rullis.\nPaliks pāri',str((requiredLinoleumArea-linoleumArea)),'m^2 linoleja.')

