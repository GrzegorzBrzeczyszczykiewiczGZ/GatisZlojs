import fnmatch
import random
import os
import sys

path = os.path.realpath(sys.path[0])

def checkDirectory(): #ja galvenās mapes nepastāv, tās izveido
    if os.path.exists(os.path.join(path, "words")) == False or os.path.exists(os.path.join(path, "sentences")) == False: #uztaisa mapes, kad pirmo reizi uzsāk programmu
        os.mkdir(os.path.join(path, "words"))
        os.mkdir(os.path.join(path, "sentences"))

def checkExit(inp): #lietoju šo funkciju kodā pēc katra ievada, lai pārbaudītu, vai lietotājs grib iziet no programmas
    if str(inp) == "stop" or str(inp) == "exit" or str(inp) == "iziet":
        print("Jūs izgājāt no programmas!")
        sys.exit(0)

def getChoice(): #funkcija paprasu lietotājam katrā programmas cikla sākumā, ko vēlas darīt
    choice = input("""
Lūdzu izvēlieties, ko vēlaties darīt, ierakstot atbilstošo ciparu:

1 - Redzēt pierakstītos vārdus un teikuma daļas
2 - Pievienot datni
3 - Noņemt datni
4 - Pievienot vārdu vai teikuma daļu
5 - Noņemt vārdu vai teikuma daļu
6 - Apskatīt mainīgo nosaukumu veidošanas noteikumus
7 - Izveidot prognozes 12 horoskopiem

: """)
    print()
    checkExit(choice)
    return choice

def writeFile(data, directory, fileName): #funkcija ierakstu datus .txt datnē
    filePath = os.path.join(path, directory)
    filePath = os.path.join(filePath, fileName)
    with open(filePath,"a", encoding="utf-8") as file:
        file.write(data)

def getFileContent(directory): #izveido sarakstu, kas sastāv no visiem mainīgajiem kādā datnē
    with open(directory, "r", encoding='utf-8') as file:
        fileContent = file.read()
        tempVariableList = fileContent.split("\n")
        tempVariableList.remove("")
        return tempVariableList

def listFiles(directory, fileType): #atgriež sarakstu ar datnēm, kas atrodas programmas mapē
    fileList = []
    filePath = os.path.join(path, directory)
    for file in os.listdir(filePath):
        if fnmatch.fnmatch(file, fileType):
            fileList.append(file)
    return fileList

def wordOrSentence(): #ļauj lietotājam izvēlēties, vai datne sastāv no vārdiem vai teikuma daļām
        folderType = input("Ja tās ir vārdu datnes, rakstiet '1': ")
        checkExit(folderType)
        return folderType

def printFileList(listOfWordFiles, listOfSentenceFiles, folderType): #printē sarakstu ar datnēm
        fileDict = {}
        i = 0
        
        if folderType == "1":
            for file in listOfWordFiles:
                i += 1
                fileDict[i] = file
        else:
            for file in listOfSentenceFiles:
                i += 1
                fileDict[i] = file
        
        fileKeys = fileDict.keys()
        print()
        for key in fileKeys:
            print(f"{key} - {fileDict[key]}")
        
        return fileDict

def chooseFile(listOfWordFiles, listOfSentenceFiles, folderType): #ļauj lietotājam izvēlēties datni, ar ko strādāt
        fileDict = printFileList(listOfWordFiles, listOfSentenceFiles, folderType)
        userFileNum = int(input("Uzrakstiet datnes skaitli: "))
        checkExit(userFileNum)
        fileName = fileDict[userFileNum]
        return fileName

def getFilePath(listOfWordFiles, listOfSentenceFiles):
    variableType = wordOrSentence()
    fileName = chooseFile(listOfWordFiles, listOfSentenceFiles, variableType)

    if variableType == "1":
        finalFilePath = os.path.join(path, "words", fileName)
    else:
        finalFilePath = os.path.join(path, "sentences", fileName)

    return finalFilePath

def getSentenceStructure(structureType):
        structure = random.choice(structureType)
        index = structureType.index(structure)
        structureType.pop(index) #vairs neatkārtosies vienā prognozē
        return structure

while True:
    wordFileList = listFiles("words", "*.txt")
    sentenceFileList = listFiles("sentences", "*.txt")

    userChoice = getChoice()

    if userChoice == "1": #ļauj lietotājam apskatīt datnes
        variableType = wordOrSentence()
        printFileList(wordFileList, sentenceFileList, variableType)

    elif userChoice == "2": #ļauj lietotājam pievienot datni
        variableType = input("Ja datne sastāvēs tikai no vārdiem vai vārdu savienojumiem, rakstiet '1': ") #lietotājs izvēlas, vai datne sastāvēs no teikuma daļām vai tikai vārdiem
        checkExit(variableType)

        userFileName = input("Uzrakstiet datnes nosaukumu: ")
        checkExit(userFileName)

        if variableType == "1":
            writeFile("", "words", userFileName+".txt")
        else:
            writeFile("", "sentences", userFileName+".txt")

    elif userChoice == "3": #ļauj lietotājam izdzēst datni
        finalFilePath = getFilePath(wordFileList, sentenceFileList)
        os.remove(finalFilePath)

    elif userChoice == "4": #ļauj lietotājam pievienot vārdu vai teikuma daļu datnei
        finalFilePath = getFilePath(wordFileList, sentenceFileList)

        addedText = input("Lūdzu uzrakstiet tekstu, ko vēlaties pievienot:\n")
        checkExit(addedText)

        with open(finalFilePath, 'a') as targetFile:
            targetFile.write(f"{addedText}\n")
            targetFile.close()

    elif userChoice == "5":
        finalFilePath = getFilePath(wordFileList, sentenceFileList)

        contentList = getFileContent(finalFilePath)
        contentDict = {}
        i = 0

        for content in contentList:
            i += 1
            contentDict[i] = content
        
        contentKeys = contentDict.keys()
        print()
        for key in contentKeys:
            print(f"{key} - {contentDict[key]}")
        userContentNum = input("Ievadiet teksta numuru:")
        checkExit(userContentNum)
        contentText = contentDict[int(userContentNum)] #ŠIS NESTRĀDĀ DRAUDZIŅ MĪĻO!!!!!!!!!!!!!!!!!
        contentList.remove(contentText)

        writableContent = ""
        for content in contentList:
            writableContent + f"{content}\n"

    elif userChoice == "6":

        print("""
Lai izveidotu jaunu mainīgo, ir jāseko līdzi stingriem noteikumiem.
              
Ir divu tipu mainīgie - vārda un teikuma.

Vārda tipa mainīgais ir viens vai daži vārdi.
Lai prognoze izskatītos adekvāti, šim mainīgajam ir jābūt bez lielā sākumburta (ja nav īpašvārds) un nominatīvajā locījumā (kas?).
Piemēri: 'varde', 'medus kūka', 'Jaunais gads'.
              
Teikuma tipa mainīgie ir teikums vai teikuma daļa.
Lai prognoze izskatītos adekvāti, šim mainīgajam ir jābūt ar lielo sākumburta, kā arī var iekļaut mainīgos no citām datnēm, uzraksot datnes nosaukumu kvadrātiekavās.
SVARĪGI: JŪSU IZVEIDOTIE TEIKUMI VAI TEIKUMA DAĻAS PROGRAMMĀ PARĀDĪSIES TIKAI TAD, JA TIEK PIEVIENOTS PIE 'apgalvojumi.txt', 'divdabjaTeiciens.txt' vai 'rikojumi.txt'!
Piemēri: 'Ja [dzivnieks] Jūs pamana, skrieniet!', '[vards] ir Jūsu sienās!'.""")
        
    elif userChoice == "7":
        sentenceDir = os.path.join(path, "sentences")
        #participlePhraseFile = random.choice(os.listdir(sentenceDir))
        horoscopes = getFileContent(os.path.join(path, "words", "horoskops.txt"))
        participlePhrases = getFileContent(os.path.join(sentenceDir, "divdabjaTeiciens.txt"))
        statements = getFileContent(os.path.join(sentenceDir, "apgalvojumi.txt"))
        orders = getFileContent(os.path.join(sentenceDir, "rikojumi.txt"))

        for horoscope in horoscopes:
            participlePhrase = getSentenceStructure(participlePhrases)
            statement1 = getSentenceStructure(statements)
            statement2 = getSentenceStructure(statements)
            statement3 = getSentenceStructure(statements)
            order = getSentenceStructure(orders)

            print(f"{horoscope}:\n{participlePhrase} {statement1} {statement2} {statement3} {order}")
            print("\n")



