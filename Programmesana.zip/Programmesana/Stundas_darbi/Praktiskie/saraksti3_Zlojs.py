myList=['Hello, world!',True,100,100.5]
print(myList)
