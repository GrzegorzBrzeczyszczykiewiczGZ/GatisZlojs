print('Jan\nFeb\nMar\nApr\nMai\nJūn\nJūl\nAug\nSep\nOkt\nNov\nDec')
men=input(str('Izvēlieties mēnesi, kura dienu skaitu gribat redzēt: '))
if men=='Feb' or men=='Apr' or men=='Jūn' or men=='Sep' or men=='Nov':
    if men=='Feb':
        print('28 dienas')
    else:
        print('30 dienas')
else:
    print('31 diena')