num=int(input('Ievadiet skaitli: '))
for i in range(1,11,1):
    print(num,'x',i,'=',num*i)