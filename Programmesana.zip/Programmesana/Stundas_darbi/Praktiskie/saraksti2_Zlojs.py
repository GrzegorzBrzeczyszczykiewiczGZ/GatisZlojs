myList=['Jā','Nē','Varbūt','Iespējams']
print(myList)