vecums=float(input('Ievadiet suņa vecumu gados: '))
if vecums>0:
    if vecums<2 or vecums==2:
        print('Suņa vecums ir:',vecums*10.5,'suņa gadi.')
    else:
        print('Suņa vecums ir:',21+(vecums-2)*4,'suņa gadi.')
else:
    print('Vecums nevar būt zemāks par 0!')
