for i in range(1,10,1):
    print(str(i)*i)