for i in range(0,41,1):
    print(end=str(i))
    if (i%2)==0:
        if (i%4)==0:
            print(' - Dalos gan ar 2, gan ar 4')
        else:
            print(' - Dalos ar 2')
    else:
        print()