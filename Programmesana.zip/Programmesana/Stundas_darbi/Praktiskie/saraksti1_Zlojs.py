mylist=[]
print(mylist)