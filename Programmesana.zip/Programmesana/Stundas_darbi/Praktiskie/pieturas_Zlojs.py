for i in range(1,21,1):
    print(str(i)+'. autobusa pietura')