def function(x,y):
    z = 2*(x+y)
    return(z)

a=7
rez=function(a,2+a)
print('Rezultāts:',rez)

a=6
b=2
rez2=function(a,b)
print('Funkcijas rezultāts:',rez2)