def atnemsana(x, y):
    print(x-y)

atnemsana(1, 2)

def reizinat(num1):
    return num1*8
result=reizinat(8)
print(result)