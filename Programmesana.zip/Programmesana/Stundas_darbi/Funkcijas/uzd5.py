def celToFahr(Cel):
    Fahr=round((Cel*9/5)+32,1)
    return(Fahr)

tempCel=round(float(input('Ievadiet temperatūru celsija grādos: ')),1)
tempFahr=celToFahr(tempCel)
print('Temperatūra Fārenheita grādos:',tempFahr)