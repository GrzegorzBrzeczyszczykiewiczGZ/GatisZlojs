def sumOfNums(array):
    res=0
    for num in nums:
        res+=num
    return(res)

nums=[1,2,3,4,5,6]
print(sumOfNums(nums))