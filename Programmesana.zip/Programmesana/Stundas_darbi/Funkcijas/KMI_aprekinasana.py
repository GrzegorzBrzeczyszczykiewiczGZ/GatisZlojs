def calculateKMI(weightFun,heightFun): #funkcija, kas aprēķina ĶMI
    res=weightFun/heightFun**2
    return(res)

def sayKMI(KMIFun): #funkcija, kas pasaka ĶMI
    print('Jums ĶMI ir',round(KMIFun,2))

weight=float(input('Ievadiet savu svaru (kg): '))
height=float(input('Ievadiet savu augumu (m): '))

KMI=calculateKMI(weight,height)

#nākamā loģikas ķēde pasaka lietotājam par viņa ķermeņa masu

if KMI<18.5:
    sayKMI(KMI)
    print('Jums ir nepietiekama ķermeņa masa!')
elif KMI>=18.5 and KMI<=25:
    sayKMI(KMI)
    print('Jums ir normāla ķermeņa masa!')
elif KMI>=25 and KMI<=30:
    sayKMI(KMI)
    print('Jums ir lieka ķermeņa masa!')
elif KMI>30:
    sayKMI(KMI)
    print('Jums ir aptaukošanās!')
