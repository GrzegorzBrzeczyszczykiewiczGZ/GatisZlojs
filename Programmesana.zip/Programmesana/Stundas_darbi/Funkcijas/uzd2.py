def myFunction():
    print('Hello, World!')

a=int(input('Ievadiet veselu skaitli: '))
b=int(input('Ievadiet veselu skaitli: '))

if a==b:
    myFunction()
else:
    print('Nesanāca')