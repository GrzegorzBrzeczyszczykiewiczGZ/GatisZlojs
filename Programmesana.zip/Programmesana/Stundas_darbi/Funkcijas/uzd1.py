print('Sākas programma')

def sveiks(vards):
    print('Labrīt, '+vards+'!')
    print('Prieks Tevi redzēt!')
    print('Cerams Tev ir laba diena!\n')

sveiks('Pēteri')
sveiks('Jāni')
sveiks('Anna')

platums, augstums = 5, 7
laukums = platums * augstums