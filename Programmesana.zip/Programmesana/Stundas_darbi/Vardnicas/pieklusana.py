#izveidot vārdnīcu, kas satur sarakstu
valstis = {
    'Somija':['Helsinki','Rovaniemi','Tampere','Kemijarvi','Jyvaskyle'],
    'Norvēģija':['Oslo','Bergena','Arendāla','Trumse','Molde'],
    'Dānija':['Kopenhāgena','Odense','Esbjerga','Aarhus','Ronne']
}
#1 variants ar for ciklu
'''for key, value in valstis.items():
    for i in value:
        print(key+':',i)
    print('--------------------------------')'''

#2 variants ar for ciklu vienai atslēgu grupu
for i in valstis['Dānija']:
    print(i)

#iegūt konkrētas pilsētas no vārdnīcas
print(valstis['Somija'][:3])

print(valstis['Norvēģija'][-2:])

print(valstis['Dānija'][1:5])

print(valstis['Dānija'][:-3])