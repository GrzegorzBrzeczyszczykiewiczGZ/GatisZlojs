#ar inicializācijas virkni
#key:value ir pāris
dd = {'četri':(4,'four'), 'divi':(2,'two'), 'trīs':(3,'three')} #izveido jaunu vārdnīcu
print(', '.join(dd)) #izdrukā vārdnīcu
print(len(dd))#atgriež vārdnīcas garumu
print(', '.join(dd.keys())) #atgriež atslēgas
#join noņem iekavas

#fromkeys metode vārdnīcas izveidei
dati=('viens','divi','trīs')
vertiba=int(input('¯\_(ツ)_/¯ '))
vardnica=dict.fromkeys(dati,vertiba)
print(vardnica)

