#izveidot vārdnīcu ar skaitļa tipa atslēgām
dict1={
    1:'Tev',
    2:'garšo',
    3:'āboli'
}
print('Vārdnīca ar skaitļa tipa atslēgām:')
print(dict1[1])
print(dict1[2])
print(dict1[3])

#vārdnīca bez skaitļa tipa atslēgām
dict2={
    'Auglis':'Ābols',
    'AugļuKaralis':'Mango',
    'SezonasAuglis':'Apelsīns',
}
print('Vārdnīca bez skaitļa tipa atslēgām:')
print(dict2['Auglis'])
print(dict2['Auglu karalis'])
print(dict2['Sezonas auglis'])