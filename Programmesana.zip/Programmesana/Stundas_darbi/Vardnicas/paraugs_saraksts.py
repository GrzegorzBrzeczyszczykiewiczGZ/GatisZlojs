#izveido sarakstu
aboli = ['Tev','garšo','āboli']

#izdrukāt sarakstu ar vairākām vērtībām
print(aboli[0])
print(aboli[1])
print(aboli[2])

#izveido sarakstu ar vairākām dimensijām(multi-dimensional list,like 2D array)
ediens = [['burkāni'],['siers'],['krabis'],['pasta']] 

#izdrukāt sarakstu, parādot vairākas dimensijas
print(ediens)
print(ediens[0])
print(ediens[1])
print(ediens[2])
print(ediens[1][0]) 
print(ediens[2][0]) 