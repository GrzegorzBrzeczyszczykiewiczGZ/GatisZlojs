dictionary={
    '2':'one',
    '3':'two',
    '1':'three'
}

print(dictionary, type(dictionary))

sortedDictionary = sorted(dictionary.keys(), key=lambda x:x[1])
convertedDictionary = dict(sortedDictionary)

print(convertedDictionary)