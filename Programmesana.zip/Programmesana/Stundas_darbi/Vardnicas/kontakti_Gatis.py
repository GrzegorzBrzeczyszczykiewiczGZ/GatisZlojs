stop=0
kontakti={'vards':[],'numurs':[]}
kontakti['vards']=['Anna','Zane','Jānis','Gustavs']
kontakti['numurs']=['29472967','35862153','08723464','12421595']

while stop==0:
    izvele=int(input('Rakstiet ciparu, lai izvēlētos, ko darīt.\n\t1 - Drukāt kontaktus uz ekrāna.\n\t2 - Pievienot kontaktus.\n\t3 - Izdzēst kontaktus.\n\t4 - Iziet.\n'))

    if izvele==1:
        for x in range(len(kontakti['vards'])):
            print(kontakti['vards'][x]+':',kontakti['numurs'][x])

    elif izvele==2:
        kontakti['vards'].append(input('Vārds: '))
        kontakti['numurs'].append(input('Numurs: '))

    elif izvele==3:
        vards=input('Vārds: ')
        indekss=kontakti['vards'].index(vards)
        kontakti['vards'].pop(indekss)
        kontakti['numurs'].pop(indekss)

    elif izvele==4:
        print('Jūs izgājāt no programmas!')
        stop=1