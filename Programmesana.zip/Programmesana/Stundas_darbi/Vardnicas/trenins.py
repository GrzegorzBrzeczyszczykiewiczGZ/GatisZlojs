telefoni={
    'zīmols':'Apple',
    'modelis':'14',
    'gads':'2021'
}
print('Vecā -',telefoni)
telefoni.update({'gads':'2022'})
print('Jaunā -',telefoni)

skolas={
    'nosaukums':'Ģimnāzija',
    'novads':'Sigulda',
    'skolenuSkaits':'569',
    'gads':'2019'
}
print('Vecā -',skolas)
skolas.clear()
print('Jaunā -',skolas)

augli={1:'banāni',2:'āboli',3:'bumbieri',4:'mango'}
print('Vecā -',augli)
augli.pop(2)
print('Jaunā -',augli)

skaitli={'a':100,'b':200,'c':300,'d':400}
if 200 in skaitli.values():
    print('ir 200')
