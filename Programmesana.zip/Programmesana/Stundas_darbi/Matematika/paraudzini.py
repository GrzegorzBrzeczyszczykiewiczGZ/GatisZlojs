import math #uzraksta programmas sākumā vienu reizi

skaitlis=float(input('Ievadiet skaitli: '))
print('Noapaļots uz leju:',math.floor(skaitlis)) #noapaļot uz leju
print('Noapaļots uz augšu:',math.ceil(skaitlis)) #noapaļot uz augšu

print('Pi vērtība ir',math.pi) #pi vērtība

print('Ievadītais skaitlis kvadrātā ir',math.pow(skaitlis,2)) #kāpina skaitli


#skaitļu formatēšana
x = 257921/89357
print('Bez formatēšanas skaitļa rezultāts ir',x)
print('Ar formatēšanu skaitļa rezultāts ir','%.2f'%x)
print('Ar formatēšanu (figūriekavām) skaitļa rezultāts ir','{:.2f}'.format(x))