for i in range(1,13,1):
    res=(input(f'Cik ir 7 reiz {i}? '))
    if int(res) == 7*i:
        print('Pareizi!')
    elif res == 'izlaist':
        print('Izlaists.')
    elif res == 'stop':
        break
    else:
        print('Nepareizi!')
