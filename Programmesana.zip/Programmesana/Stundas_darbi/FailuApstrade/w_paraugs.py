f=open('demo.txt','w',encoding='utf-8')
f.write('Sveiks!\n:)') #pārraksta visu