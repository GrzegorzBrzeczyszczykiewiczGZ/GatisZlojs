while True:
    fails=open('dati.txt','a',encoding='utf-8') #izveidos failu
    fails.write('Ingvera sula garšo pēc suši!\n') #pieraksta rindu
    #katru reizi palaižot programmu, rinda tiks pierakstīta klāt
    fails.close()