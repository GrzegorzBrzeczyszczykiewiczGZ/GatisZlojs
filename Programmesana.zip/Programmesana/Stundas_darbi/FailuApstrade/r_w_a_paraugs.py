#izveidot failu dati2.txt
f=open('dati2.txt','w',encoding='utf-8')

#pielikt sarakstu ar 3 pilsētām
f=open('dati2.txt','a',encoding='utf-8')
pilsetas=['Daugavpils','Čitagonga','Vladivostoka']
for object in pilsetas:
    f.write(object+'\n')
f=open('dati2.txt','r',encoding='utf-8')
print(f.read())
f.close()

#pārrakstīt faila saturu uz 3 valstīm
f=open('dati2.txt','w',encoding='utf-8')
valstis={
    'Daugavpils':'Latvija',
    'Čitagonga':'Bangladeša',
    'Vladivostoka':'Krievija'
}
for object in valstis:
    f.write(valstis[object]+'\n')   