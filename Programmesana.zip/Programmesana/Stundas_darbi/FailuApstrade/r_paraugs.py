f=open('demo.txt','r',encoding='utf-8') #atver
print(f.read()) #izdrukā saturu

f=open('demo.txt','r',encoding='utf-8')
print(f.readline()) #nolasa pirmo rindiņu

f=open('demo.txt','r',encoding='utf-8')
print(f.read(10)) #izdrukā pirmos 10 simbolus

f.close()