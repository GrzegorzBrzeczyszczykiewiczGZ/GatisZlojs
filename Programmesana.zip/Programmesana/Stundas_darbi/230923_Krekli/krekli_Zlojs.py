end_price=0
loop = True

def calc_price(num, symb): #aprēķina viena krekla kopas cenu, skatoties uz apdrukas veidu
    if symb == 'TEKSTS':
        coef = 5
    elif symb == 'ZIME':
        coef = 7
    elif symb == 'FOTO':
        coef = 20
    price=num*coef
    return(price)

def pasuti_tkreklus(skaits, apdruka, piegade):
    shipping = 0
    if piegade == True:
        shipping=15
    end_price+= package_price + shipping

    if discount == True:
        package_price = package_price*0.95

while loop == True:
    shirt_symb=input('Ar kādu druku Jūs sūtīsiet kreklus?\n(TEKSTS / ZIME / FOTO): ')
    shirt_num=int(input('Cik kreklu jūs ar šo druku sūtīsiet?: '))

    package_price = calc_price(shirt_num, shirt_symb)
    #paskatās, vai ir jāmaksā par sūtīšanu un vai ir atlaide
    if package_price < 50:
        shipping = True
    elif package_price > 100:
        discount = True

    pasuti_tkreklus(shirt_num, shirt_symb, shipping)