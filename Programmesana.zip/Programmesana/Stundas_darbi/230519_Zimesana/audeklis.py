from random import *
from tkinter import *
window=Tk()

size=1500
canvas=Canvas(window,width=size,height=size)
canvas.pack()

while True:
    color=choice(["white", "black", "red", "green", "blue", "cyan", "yellow", "magenta"])
    x0=randint(0, size)
    y0=randint(0, size)
    ball=randint(0, size/100)
    canvas.create_rectangle(x0, y0, x0+ball, y0+ball, fill=color, outline=color)
    window.update()
mainloop()