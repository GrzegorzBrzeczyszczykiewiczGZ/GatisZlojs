#izveidot sarakstu 'atzimes' ar punktiem (testā iegūtajiem) (10 rezultāti no 71 - 99)
#ar for ciklu iziet cauri visam sarakstam
#ar elif nosacījumu uz ekrāna parādīt punktus un atzīmi
# >=90 - A ; >=80 - B ; starp 70 un 80 - C ; no 60 līdz 70 - D, ja krīt zem 60 - F
#var pielikt datu ievadi
atzimes=[]
n = int(input("Ievadiet rezultātu skaitu: "))

for i in range(0, n):
    rezultats = int(input())
    atzimes.append(rezultats)

for punkti in atzimes:
    if punkti>=90:
        print(punkti,'A')
    elif punkti>=80:
        print(punkti,'B')
    elif punkti>=70:
        print(punkti,'C')
    elif punkti>60:
        print(punkti,'D')
    else:
        print(punkti,'F')