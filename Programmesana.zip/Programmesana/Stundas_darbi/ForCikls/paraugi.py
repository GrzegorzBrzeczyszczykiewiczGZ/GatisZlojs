for i in range(2,11,2):
#sāk ar 2, iet līdz 11 (neieskaitot), ik pa 2
    print(i)

vards='Gatis'
for burts in vards:
    print(burts)

#izdrukāt skaitļus no 1 līdz 100
for i in range(1,101,1):
    print(i,end=' ')