#uzraksti programmu, kurā ir 2 saraksti. Ar + abus apvienot

#myList=['svece',2,'sāls',True] #pirmais elements ir ar indeksu 0
#yourList=['karstmaizes','brauniji','kafija'] #

#bothList=myList+yourList
#print(bothList)

#nokopēt saraksta vērtības un ielikt tās jaunā sarakstā
#milzis=['zupa','dzervene','tastastūra']
#jauns=list(milzis)
#print(milzis)
#print(jauns)

#izveidot sarakstu ar 4 krāsu nosaukumiem. Atrast katra elementa garumu
krasas=['zils','zaļš','dzeltens','balts']
jaunsSaraksts=[] #tukšs saraksts
for krasa in krasas:
    burti=0 #katru reizu palaižot sarakstu, vērtība kļūst par 0
    for burts in krasa:
        burti+=1
    pagaiduSaraksts=[krasa,burti]
    jaunsSaraksts.append(pagaiduSaraksts)
print(jaunsSaraksts)

#Kā šo kodu var uzrakstīt ar mazāk rindiņām? Vai ir vienkāršāks veids, kā atrast katra vārda garumu?
krasas1=['zils','zaļš','dzeltens','balts']
for krasa1 in krasas1:
    print(krasa1,len(krasa1))
    
#variants3

listOfWords=['blue','yellow','red','green']
newList=[]
for color in listOfWords:
    newList.append([color,len(color)])
print(newList)