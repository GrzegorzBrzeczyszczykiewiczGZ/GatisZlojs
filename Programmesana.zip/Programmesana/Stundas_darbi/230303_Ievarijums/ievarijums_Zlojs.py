import sys

#--- Vidējās tirgus cenas ---
#1 kg ievārījuma cukura maksā 2,59€
#1 kg parastā cukura maksā 1,25€
#1 kg mandeļa ekstraksts maksā 58,22€
#1 kg kanēļa maksā 37,25€
#1 kg ābolu maksā 1,00€
#1 kg citrona maksā 2,29€

totalCost=0.0

def calculateCost(finalMass, mass, cost, product):
    cost=0
    massDifference=finalMass-mass
    cost=round(massDifference*cost,2)
    print('Jums būs jānopērk vēl',massDifference,'kg ',product,'par',cost,'eiro')        

def checkQuit(inp): #lietoju šo funkciju kodā pēc katra ievada, lai pārbaudītu, vai lietotājs grib iziet no programmas
    if str(inp) == 'stop' or str(inp) == 'exit' or str(inp) == 'beigt' or str(inp) == 'iziet':
        print('Jūs izgājāt no programmas!')
        sys.exit(0)

def checkNegative(inp): #pārbauda, vai lietotājs nav ievadījis negatīvu vērtību, ja ir negatīva vērtība, tad prasa jaunu vērtību līdz nav vairs negatīvs
    while inp < 0:
        inp=float(input('Vērtība nedrīkst būt negatīva! Ierakstiet atkal: '))


print('Sveiki! Ar šo programmu Jūs varēsiet aprēķināt, cik jums ābolu ievārījuma sanāks!')
print('\n3 kg ābolu\n1 kg cukura\n500 ml ūdens\n1 gab citrons\n5 ml mandeļu ekstrakta\n10 g kanēļa\n\n----------------------------\n1,5 litri ievārījuma')
agreeToRecipe=input('Vai jūs vēlaties izmantot mūsu recepti vai savu? Rakstiet "jā" vai "nē": ') #prasa lietotājam, vai vēlas lietot programmas recepti
checkQuit(agreeToRecipe)

if agreeToRecipe == 'jā':
    appleMass=float(input('Cik kg ābolu Jums ir? Ievadiet skaitli: ')) #prasa ābolu masu
    checkQuit(appleMass)
    checkNegative(appleMass)

    lemonNum=int(input('Cik gabalu citronu Jums ir? Ievadiet skaitli: ')) #prasa citronu skaitu
    checkQuit(lemonNum)
    checkNegative(lemonNum)
    lemonNum=int(lemonNum) #ja lietotājs sākotnēji ievadīja negatīvu skaitlis, šis pārveido float vērtību no checkNegative funkcijas uz integer vērtību
    lemonMass=lemonNum*0.12 #aprēķina citronu masu

    almondExtractMass=float(input('Cik ml mandeļu ekstrakta Jums ir? Ievadiet skaitli: ')) #prasa mandeļu ekstrakta tilpumu
    checkQuit(almondExtractMass)
    checkNegative(almondExtractMass)
    almondExtractVolume=almondExtractMass/1000 #pārveido mililitrus uz kilogramiem

    cinnamonMass=float(input('Cik g kanēļa Jums ir? Ievadiet skaitli: '))
    checkQuit(cinnamonMass)
    checkNegative(cinnamonMass)
    cinnamonMass=cinnamonMass/1000 #pārveido gramus uz kilogramiem

    sugarType=input('Vai Jūs vēlaties lietot parasto vai ievārījuma cukuru?\nRakstiet "parasto" vai "ievārījuma": ') #prasa lietotājam vēlamo cukura veidu
    checkQuit(sugarType)
    sugarMass=float(input('Cik kg cukura Jums ir? Ievadiet skaitli: ')) #prasa cukura masu
    checkQuit(sugarMass)
    checkNegative(sugarMass)



    if appleMass >= 3: #ja ābolu masa ir pietiekama, lietotājam ir opcija izvēlēties, vai pirkt vēl ābolus
        buyMoreApples=input('Vai Jūs taisīsiet ievārījumu līdz Jums āboli beigsies, vai Jūs esat gatavi maksāt par papildus āboliem?\nJa esat gatavi maksāt par āboliem, rakstiet "jā", ja neesat, rakstiet "nē": ')
        checkQuit(buyMoreApples)
    
    else: #ja ābolu masa nav pietiekama, lietotājam liek pirkt vēl ābolus
        buyMoreApples='jā'

    budget=round(float(input('Cik € ir Jūsu budžetā? Ievadiet skaitli: ')),2) #prasa lietotāja budžetu

    if buyMoreApples == 'jā':
        
        while buyMoreApples == 'jā':
            finalAppleMass=float(input('Cik kg ābolu Jūs gribat? Ievadiet skaitli: ')) #prasa vēlēto ābolu masu
            checkQuit(finalAppleMass)
            checkNegative(finalAppleMass)
            if appleMass < finalAppleMass: #aprēķina vajadzīgo ābolu masu un cenu
                cost=0
                appleMassDifference=finalAppleMass-appleMass
                cost=round(appleMassDifference*1.00,2)
                if budget < cost: #ja budžets pārāk mazs, prasa lietotājam ievadīt citu vēlamo ābolu masu
                    print('Jūsu budžets ir pārāk mazs, izvēlieties citu daudzumu.')
                    continue
                print('Par',appleMassDifference,'kg ābolu Jums ir jāmaksā',cost,'eiro.')
                totalCost+=cost
            break
        
    appleCoeficient=finalAppleMass/3 #koeficients, ar ko varēs noteikt citas vērtības, lai citas sastāvdaļas būtu proporcionālas āboliem

    #nākamās līnījas aprēķina galējās masas un cenu, kas jāmaksā, lai iegūtu sastāvdaļas

    finalLemonMass=lemonMass*appleCoeficient
    if lemonMass < finalLemonMass: #aprēķina vajadzīgo citronu masu un cenu
        lemonCost=calculateCost(finalLemonMass,lemonMass,2.29,'citrona.')
        totalCost+=lemonCost

    finalAlmondExtractMass=almondExtractMass*appleCoeficient
    if almondExtractMass < finalAlmondExtractMass:
        almondExtractCost=calculateCost(finalAlmondExtractMass,almondExtractMass,58.22,'mandeļu ekstrakta.')
        totalCost+=almondExtractCost

    finalCinnamonMass=cinnamonMass*appleCoeficient
    if cinnamonMass < finalCinnamonMass:
        cinnamonCost=calculateCost(finalCinnamonMass,cinnamonMass,37.25,'kanēļa.')
        totalCost+=cinnamonCost

    finalSugarMass=sugarMass*appleCoeficient
    if sugarMass < finalSugarMass:
        if sugarType == 'parasto':
            sugarCost=calculateCost(finalSugarMass,sugarMass,1.25,'parastā cukura.')
            totalCost+=sugarCost
        elif sugarType == 'ievārījuma':
            sugarCost=calculateCost(finalSugarMass,sugarMass,2.59,'ievārījuma cukura.')
            totalCost+=sugarCost
        
    

    jamVolume=1.5*appleCoeficient

    print('Jums būs',jamVolume,'ābolu ievārījuma.')
    print('Kopā Jums izmaksās',totalCost,'eiro.')
    print('Jūsu budžets bija',budget,'eiro.')

