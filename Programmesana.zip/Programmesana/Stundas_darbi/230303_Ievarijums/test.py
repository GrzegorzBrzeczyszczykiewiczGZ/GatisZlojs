mass=2
mass*=3
print(mass)