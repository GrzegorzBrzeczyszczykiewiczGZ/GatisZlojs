def handkerchiefSum(num):
    result = 0
    adder = ''
    for digit in num:
        adder += digit
        result += int(adder)
    return(result)

while True:
    userInput = input().split()

    smallNum = int(userInput[0])
    bigNum = int(userInput[1])

    smallest = 0
    largest = 0

    for num in range(1, bigNum+1):
        currentNum = str(num)
        result = handkerchiefSum(currentNum)
        if result >= smallNum and result <= bigNum:
            smallest = num
            break
    for num in range(bigNum+1, 0, -1):
        currentNum = str(num)
        result = handkerchiefSum(currentNum)
        if result >= smallNum and result <= bigNum:
            largest = num
            break

    print(smallest, largest)
    continue