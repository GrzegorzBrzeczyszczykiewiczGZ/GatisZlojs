while True:
    def takeOutCards(cards, min, max): #funkcija atgriež jaunu sarakstu, kurā nav iekļautas tie žetoni, kuri bija lietotāja specificētajā diapazonā
        finalCards = []
        for num in cards:
            if num < min or num > max:
                finalCards.append(num)
        return finalCards

    userStartInput = input().split()

    cardAmount = int(userStartInput[0])
    smallDivisor = int(userStartInput[1])
    bigDivisor = int(userStartInput[2])
    roundAmount = int(userStartInput[3])

    if cardAmount > 10**18:
        continue
    if smallDivisor > 10**9 or bigDivisor > 10**9:
        continue
    if roundAmount > 10**5:
        continue


    goodCards = []
    for num in range(1, cardAmount+1): #šis cikls pieliek klāt "goodCards" sarakstam visus "labos žetonus"
        if num % smallDivisor == 0 or num % bigDivisor == 0:
            goodCards.append(num)

    for i in range(roundAmount): #atkārtojas tik reižu, cik lietotājs ir izvēlējies gājienu      
        while True:
            userRange = input().split()
            minNum = int(userRange[0])
            maxNum = int(userRange[1])
            if minNum > maxNum or maxNum > 10**18:
                continue
            break
        goodCardsFinal = takeOutCards(goodCards, minNum, maxNum)
        goodCards = goodCardsFinal
        goodCardAmount = 0
        for card in goodCards:
            goodCardAmount += 1

    print(goodCardAmount)

#īsumā - rakstiskā saskaitīšana būtu matemātiskais veids, proti, ja ir 1234, tad S(1234)