from collections import Counter

while True:
    userInput = input().split()
    S = int(userInput[0])
    N = int(userInput[1])
    if S > 10**5 or N > 10**5 or S*N > 10**6: #ja ievaddati neatbilst nosacītajiem diapazoniem, tad tiek pieprasīti vēlreiz
        continue
    break

athleteInfo = {}
for s in range(S):
    endScore = 0
    athleteScores = input().split()
    for score in athleteScores:
        if score == "1":
            endScore += 25
        elif score == "2":
            endScore += 18
        elif score == "3":
            endScore += 15
        elif score == "4":
            endScore += 12
        elif score == "5":
            endScore += 10
        elif score == "6":
            endScore += 8
        elif score == "7":
            endScore += 6
        elif score == "8":
            endScore += 4
        elif score == "9":
            endScore += 2
        elif score == "10":
            endScore += 1
    athleteInfo[s+1]:endScore
    print(athleteInfo)

maxScore = max(athleteInfo)
maxScoreNum = 0
repeatedScores = Counter(athleteInfo.values())
for key in repeatedScores:
    if key == maxScore:
        maxScoreNum += repeatedScores[key]
        break
print(maxScore, maxScoreNum)

