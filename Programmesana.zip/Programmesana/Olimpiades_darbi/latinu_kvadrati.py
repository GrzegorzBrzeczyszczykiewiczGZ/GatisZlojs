while True:
    userStartInput = input().split()
    m = int(userStartInput[0])
    k = int(userStartInput[1])
    n = int(userStartInput[2])

    if m < 2 or m > 5*10**5:
        continue
    if k < 2 or k > 5*10**5:
        continue
    if m*k > 10**6:
        continue
    if n < 2 or n > 62:
        continue

    table = []
    for i in range(0, m): #tiek pieprasīti simboli katrai rindai
        while True:
            table[i] = input()
            if len(table[i]) != k: #ja ievadīto simbolu skaits neatbilst kolonnu skaitam, tiek pieprasīta rindas simboli vēlreiz
                continue
            break

    for i in table:
        latinSquare = []
        for j in table[i]:
            for y in range(n):
                for x in range(n):
                    latinSquare.append(table[i+y][j+x])
                #for

