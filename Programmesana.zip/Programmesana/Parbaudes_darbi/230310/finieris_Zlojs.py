import sys

def parbauditIziesanu(inp): #lietoju šo funkciju kodā pēc katra ievada, lai pārbaudītu, vai lietotājs grib iziet no programmas
    if str(inp) == 'stop' or str(inp) == 'exit' or str(inp) == 'beigt' or str(inp) == 'iziet':
        print('Jūs izgājāt no programmas!')
        sys.exit(0)

def parbauditNegativu(inp): #pārbauda, vai lietotājs nav ievadījis negatīvu vērtību, ja ir negatīva vērtība, tad prasa jaunu vērtību līdz nav vairs negatīvs
    while inp < 0:
        inp=float(input('Vērtība nedrīkst būt negatīva! Ierakstiet atkal: '))

def materialuUzskaite(garums, platums, augstums, skaits, tips): #izveido saraksta tipa mainīgo no lietotāja ievadītajiem datiem
    if tips=='finieris':
        materials=[garums, platums, augstums, skaits, tips]
        return(materials)
    
    elif tips=='liste' or tips=='stūris':
        materials=[skaits, tips]
        return(materials)
    
def materialuAprekins(podestaGarums, podestaPlatums, podestaAugstums, podestuSkaits):
    skaits=int(input('Cik Jums ir finiera saplākšņu? '))
    if skaits>0:
        garums=round(float(input('Kāds garums vienam saplāksnim (cm)? ')),1)
        parbauditIziesanu(garums)
        parbauditNegativu(garums)
        augstums=round(float(input('Kāds augstums vienam saplāksnim (cm)? ')),1)
        parbauditIziesanu(augstums)
        parbauditNegativu(augstums)
        platums=round(float(input('Kāds biezums vienam saplāksnim (cm)? ')),1)
        parbauditIziesanu(platums)
        parbauditNegativu(platums)
    else:
        garums=0
        augstums=0
        platums=0
    finieraMaterialsRezerve=materialuUzskaite(garums, platums, augstums, skaits, 'finieris') #izveido sarakstu ar finiera skaitu, kas jau ir, garumu, platumu un augstumu

    skaits=int(input('Cik Jums ir līstu? '))
    listuMaterialsRezerve=materialuUzskaite(0, 0, 0, skaits, 'liste') #izveido sarakstu ar listu skaitu, kas jau ir

    skaits=int(input('Cik Jums ir stūru? '))
    sturuMaterialsRezerve=materialuUzskaite(0, 0, 0, skaits,'stūris') #izveido sarakstu ar stūru skaitu, kas jau ir

    pamatuKopLaukums=(podestaGarums*podestaAugstums*podestuSkaits) #pamatu malu kopējais laukums
    sanuKopLaukums=(podestaGarums*podestaPlatums*podestuSkaits) #sānu malu kopējais laukums
    prieksuKopLaukums=(podestaPlatums*podestaAugstums*podestuSkaits) #priekšu (tai skaitā aizmugurējo) malu kopējais laukums
    podestaKopLaukums=pamatuKopLaukums+sanuKopLaukums+prieksuKopLaukums #visu podestu malu kopējais laukums

    irPodestaKopLaukums=(finieraMaterialsRezerve[0]*finieraMaterialsRezerve[2])*finieraMaterialsRezerve[3] #aprēķina, cik lietotājam ir finiera
    navPodestaKopLaukums=podestaKopLaukums-irPodestaKopLaukums #visu podestu malu kopējais laukums, kas ir jāiegādājas

    listuKopSkaits=(podestuSkaits*12) #vajadzīgais listu skaits
    navListuKopSkaits=listuKopSkaits-listuMaterialsRezerve[0] #vajadzīgais listu skaits, kas ir jāiegādājas

    sturuKopSkaits=(podestuSkaits*8) #vajadzīgais stūru skaits
    navSturuKopSkaits=sturuKopSkaits-sturuMaterialsRezerve[0] #vajadzīgais stūru skaits, kas ir jāiegādājas

    if podestaKopLaukums>irPodestaKopLaukums:
        print('Podestiem vajag',podestaKopLaukums,'cm^2 finiera. Jums ir ',irPodestaKopLaukums,'cm^2. Vajag vēl',navPodestaKopLaukums,'cm^2 finiera.')
        print('Jums finieris izmaksās',round((navPodestaKopLaukums/10000)*finieraCena,2),'€.')
    else:
        print('Podestiem vajag',podestaKopLaukums,'cm^2 finiera. Jums ir ',irPodestaKopLaukums,'cm^2.')
    
    if listuKopSkaits>listuMaterialsRezerve[0]:
        print('Podestiem vajag',listuKopSkaits,'līstes. Jums ir',listuMaterialsRezerve[0],'līstes. Vajag vēl',navListuKopSkaits,'līstes.')
        print('Jums līstes izmaksās',round(navListuKopSkaits*listeCena,2),'€.')
    else:
        print('Podestiem vajag',listuKopSkaits,'līstes. Jums ir',listuMaterialsRezerve[0],'līstes.')

    if sturuKopSkaits>sturuMaterialsRezerve[0]:
        print('Podestiem vajag',sturuKopSkaits,'stūri. Jums ir',sturuMaterialsRezerve[0],'stūri. Vajag vēl',navSturuKopSkaits,'stūrus.')
        print('Jums stūri izmaksās',round(navSturuKopSkaits*sturaCena,2),'€.')
    else:
        print('Podestiem vajag',sturuKopSkaits,'stūri. Jums ir',sturuMaterialsRezerve[0],'stūri.')

sturaCena=3.00
listeCena=5.67
finieraCena=14.45 #finiera cena uz kvadrātmetru

print('Sveiki! Šī programma aprēķinās, cik Jums materiālu vajag podesta izveidei!')
print('Vispirms vajag uzzināt, cik materiālu Jums jau ir.')

podestaGarums=round(float(input('Kāds būs podesta garums (cm)? ')),1)
parbauditIziesanu(podestaGarums)
parbauditNegativu(podestaGarums)

podestaPlatums=round(float(input('Kāds būs podesta biezums (cm)? ')),1)
parbauditIziesanu(podestaPlatums)
parbauditNegativu(podestaPlatums)

podestaAugstums=round(float(input('Kāds būs podesta augstums (cm)? ')),1)
parbauditIziesanu(podestaAugstums)
parbauditNegativu(podestaAugstums)

podestuSkaits=int(input('Cik podestus Jūs taisīsiet? '))
parbauditIziesanu(podestuSkaits)
parbauditNegativu(podestuSkaits)

materialuAprekins(podestaGarums, podestaPlatums, podestaAugstums, podestuSkaits)