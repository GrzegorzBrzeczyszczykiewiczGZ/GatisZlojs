myList=[1,2,3,4]
print(myList[3])