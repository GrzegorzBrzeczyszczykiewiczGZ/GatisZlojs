stopPurchase='0'
receipt='Iepirkšanās čeks:'
sumPurchasePriceNoDiscount=0.0
sumPurchasePrice=0.0
print('Ar šo programmu jūs varēsiet izvēlēties kāda veikala atlaidi lietot Jūsu precēm un cik tas jums izmaksās.\n')

while stopPurchase=='0':
    receipt+='\n\n'

    productNum=int(input('Ievadiet preču skaitu: '))
    if productNum<0:
        exit
    productName=input('Ievadiet preces nosaukumu: ')
    productPrice=round(float(input('Ievadiet cenu vienam šīs preces gabalam: ')),2) #Prasa lietotājaam cenu, kā arī to noapaļo līdz 2 cipariem aiz komata

    print('\n1 - Maxima: 30% atlaide\n2 - Elvi: 40% atlaide, ja ir klienta karte\n3 - Rimi: 20%, bet 50%, ja ir klienta karte\n4 - Mego: 30%, ja pērk 3 preces un vairāk\n5 - Aibe: Katra 2. prece par brīvu\n')
    discountChoice=input('Izvēlieties, kurā veikalā Jūs vēlaties iepirkties, atlaides atšķiras starp veikaliem, rakstiet ciparu: ') #Prasa lietotājam viņa vēlamo atlaides veidu

    purchasePriceNoDiscount=productPrice*productNum
    purchasePrice=purchasePriceNoDiscount



    #Tālāk notiek rēķināšana ar atlaidēm
    if discountChoice=='1':
        purchasePrice*=0.7

    elif discountChoice=='2':
        membership=input('Ievadiet "1", ja ir klienta karte, "0", ja nav: ') #Prasa lietotājam, vai viņam ir klienta karte
        if membership=='1':
            purchasePrice*=0.6

    elif discountChoice=='3':
        membership=input('Ievadiet "1", ja ir klienta karte, "0", ja nav: ') #Prasa lietotājam, vai viņam ir klienta karte
        if membership=='1':
            purchasePrice*=0.5
        else:
            purchasePrice*=0.8
    
    elif discountChoice=='4':
        if productNum>=3:
            purchasePrice*=0.7

    elif discountChoice=='5':
        if productNum%2==0:
            purchasePrice/=2
        else: #Šeit atņem 1 gabala cenu no kopējās cenas, ja ir nepāra skaitlis gabalu, pēc tam atņem katra otro cenu un pieskaita 1 gabala cenu atkal
            purchasePrice-=productPrice
            purchasePrice/=2
            purchasePrice+=productPrice
    


    purchasePriceNoDiscount=round(purchasePriceNoDiscount,2)
    purchasePrice=round(purchasePrice,2)

    sumPurchasePriceNoDiscount+=purchasePriceNoDiscount
    sumPurchasePrice+=purchasePrice

    receipt+=productName+'\n'+str(productPrice)+' X '+str(productNum)+'\t\t\t'+str(purchasePriceNoDiscount)+'\nAr atlaidi:\t\t\t'+str(purchasePrice)

    stopPurchase=input('\nVai ir nopirkts viss, kas sarakstā?\nJa esat beiguši iepirkšanos, rakstiet "1", ja vēlaties turpināt iepirkties, rakstiet "0": ')

round(sumPurchasePriceNoDiscount,2)
round(sumPurchasePrice,2)


receipt+='\n\n-------------------------\n\n'
receipt+=f'Kopā beiz atlaides (EUR):\t{sumPurchasePriceNoDiscount}\nKopā ar atlaidēm (EUR):\t\t{sumPurchasePrice}\n\n'
receipt+='-------------------------\n\n'
receipt+=f'Kopā apmaksai (EUR):\t\t{sumPurchasePrice}'
print(receipt)
exit


    
    





