from datetime import datetime
import os
import sys

path = os.path.join(os.path.realpath(sys.path[0]), "eksperimentaDati.txt")

def checkExit(inp): #lietoju šo funkciju kodā pēc katra ievada, lai pārbaudītu, vai lietotājs grib iziet no programmas
    if str(inp) == 'stop' or str(inp) == 'exit' or str(inp) == 'iziet':
        print('Jūs izgājāt no programmas!')
        sys.exit(0)

#pārbauda, vai ievaddati sākas ar lielo burtu un vai lietotājs cenšas iziet no programmas (pasauc checkExit() funckiju)
def correctName(oldString):
    newString = " ".join(oldString.split()) #izveido string vērtību bez tukšumiem pirms vai pēc, kā arī bez pārpildus daudz tukšumu starp vārdiem
    checkExit(newString)
    while True:
        if newString[0].islower():
            newString = input('Ievadītajiem datiem jāsākas ar lielo burtu, ievadiet no jauna: ')
            checkExit(newString)
            newString = " ".join(newString.split())
        else:
            return newString
        
#lietotāja ievaddatus sakārto vienā string vērtībā, kas tiek lietots citā funkcijā, lai rakstītu teksta datnē
def sortData(expName, time, name, location):
    lietotaja_eksp_dati = f"""
Nosaukums: {expName}
Laiks: {time}
Lietotājvārds: {name}
Vieta: {location}
    """
    return lietotaja_eksp_dati

def getData(): #specifikācijā funkcija nosaukta par "iegut_datus()"
    expName = input("\nIevadiet eksperimenta nosaukumu: ")
    expName = correctName(expName)

    time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    name = input("Ievadiet savu vārdu: ")
    name = correctName(name)

    location = input("Ievadiet eksperimenta veikšanas vietu: ")
    location = correctName(location)

    return sortData(expName, time, name, location)

#izmantojot "dati" parametru, ieraksta šo vērtību teksta tipa datnē, nepārrakstot iepriekšējos datus
def saveData(dati): #specifikācijā funkcija nosaukta par "saglabat_datus"
    with open(path,"a", encoding="utf-8") as file:
        file.write(dati)

#galvenā programmas funkcija, veic visu nepieciešamo
def main(): #specifikācijā funkcija nosaukta par "galvena()"
    print("Sveiki! Šī programma ļaus Jums pierakstīt iegūtos datus no eksperimenta!.\n---------")
    while True:
        saveData(getData())

main()