import math

def printAsterisks(amount): #funkcijā var ielikt jebkādu veselu skaitli, izprintēs tāda skaita zvaigznīšu
    print(amount*'*')

def calcFactorial(num): #izmanto math funkciju 'factorial', lai aprēķinātu faktoriāli
    return math.factorial(num)

def emptySpace():
    print('\n')

def main():
    print('Faktoriāla aprēķināšana')
    printAsterisks(55)
    while True: #ir izveidots cikls, kas prasa ievadīt skaitli, kura faktoriālu aprēķina un izprintē, kamēr lietotājs nav to apstādinājis
        userNum=int(input('Ievadiet veselu pozitīvu skaitli (mazāku par 13):\n'))
        if userNum>=13: #ja skaitlis nav mazāks par 13, tad neaprēķina faktoriāli
            print('Ievadītais skaitlis ir pārāk liels!')
        else: #ja skaitlis ir lielāks par 13, tad aprēķina faktoriāli
            userNum=calcFactorial(userNum) #pārveido ievadīto skaitli par tā faktoriāli
            print('Faktoriāls:',userNum)
        userChoice=input('Vai vēlaties turpināt darbu (j-jā, citi taustiņi-nē)?\n')
        emptySpace()
        if userChoice=='j': #ja lietotājs vēlas, cikls turpinās
            continue
        else:
            break
    print('Paldies!')

main()