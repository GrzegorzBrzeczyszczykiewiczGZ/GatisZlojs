
#alphabet="aābcčdeēfgģhiījkķlļmnņoprsštuūvzž"
alphabet = "AaĀāBbCcČčDdEeĒēFfGgĢģHhIiĪīJjKkĶķLlĻļMmNnŅņOoPpRrSsŠšTtUuŪūVvZzŽž"
countries={
    'Ķīna':1411750000,
    'Indija':1392329000,
    'ASV':334653000,
    'Indonēzija':275773800,
    'Pakistāna':235825000,
    'Nigērija':218541000,
    'Brazīlija':216045240,
    'Bangladeša':169828911,
    'Meksika':128665641,
    'Japāna':124470000,
}
countryNames = list(countries.keys())
print(sorted(countryNames, key=lambda word: [alphabet.index(c) for c in word]))
