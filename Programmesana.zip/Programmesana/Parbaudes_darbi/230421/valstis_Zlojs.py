import sys

def checkExit(inp): #lietoju šo funkciju kodā pēc katra ievada, lai pārbaudītu, vai lietotājs grib iziet no programmas
    if str(inp) == 'stop' or str(inp) == 'exit' or str(inp) == 'beigt' or str(inp) == 'iziet':
        print('Jūs izgājāt no programmas!')
        sys.exit(0)
    
countries={
    'Ķīna':1411750000,
    'Indija':1392329000,
    'ASV':334653000,
    'Indonēzija':275773800,
    'Pakistāna':235825000,
    'Nigērija':218541000,
    'Brazīlija':216045240,
    'Bangladeša':169828911,
    'Meksika':128665641,
    'Japāna':124470000,
}

alphabet = "AaĀāBbCcČčDdEeĒēFfGgĢģHhIiĪīJjKkĶķLlĻļMmNnŅņOoPpRrSsŠšTtUuŪūVvZzŽž"

while True:
    userChoice=input('''
--------------------------------------------------
1 - valstu nosaukumi (augošs)
2 - valstu nosaukumi (dilstošs)
3 - valstu iedzīvotāju skaiti (augošs)
4 - valstu iedzīvotāju skaiti (dilstošs)
5 - pievienot jaunu valsti
6 - apskatīt visas valstis
--------------------------------------------------

: ''')

    checkExit(userChoice)

    if userChoice=='1': #uztaisa sarakstu ar valsts nosaukumiem, tos sakārto, tad pārraksta vārdnīcu alfābetiskā secībā
        countryNames = list(countries.keys())
        countryNames.sort(key=lambda name: [alphabet.index(i) for i in name]) #izmanto latviešu alfabētu, lai sakārtotu nosaukumus
        countries = {name: countries[name] for name in countryNames}
        continue
    elif userChoice=='2': #uztaisa sarakstu ar valsts nosaukumiem, tos sakārto, tad pārraksta vārdnīcu pret alfābetisko secību
        countryNames = list(countries.keys())
        countryNames.sort(key=lambda name: [alphabet.index(i) for i in name], reverse=True) #izmanto latviešu alfabētu, lai sakārtotu nosaukumus, bet pretēji alfabētam
        countries = {name: countries[name] for name in countryNames}
        continue
    elif userChoice=='3': #sakārto valstis pēc iedzīvotāja skaita (vārdnīcas vērtībām) augoši
        sortedCountries=sorted(countries.items(), key=lambda x:x[1])
        countries=dict(sortedCountries)
        continue
    elif userChoice=='4': #sakārto valstis pēc iedzīvotāja skaita (vārdnīcas vērtībām) dilstoši
        sortedCountries=sorted(countries.items(), key=lambda x:x[1], reverse=True)
        countries=dict(sortedCountries)
        continue
    elif userChoice=='5': #lietotājs var ievadīt pats valsts nosaukumu un iedzīvotāju skaitu
        name=input('Valsts nosaukums: ')
        checkExit(name)
        population=input('Iedzīvotāju skaits: ')
        checkExit(name)
        countries[name]=int(population)
        continue
    elif userChoice=='6':
        for name in countries:
            print(name,'-',countries[name])
        continue
        