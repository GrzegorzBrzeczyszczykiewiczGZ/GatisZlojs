import sys

def checkExit(inp): #lietoju šo funkciju kodā pēc katra ievada, lai pārbaudītu, vai lietotājs grib iziet no programmas
    if str(inp) == 'stop' or str(inp) == 'exit' or str(inp) == 'beigt' or str(inp) == 'iziet':
        print('Jūs izgājāt no programmas!')
        sys.exit(0)

def printDict(dict1, dict2): #izprintē vārdnīcas atslēgas un vērtības, ja ir 2 saraksti
    print()
    for x in range(len(dict1)):
            print(dict1[x]+':',dict2[x])
    print()

stop=0
class10a={'name':[],'height':[]}
class10a['name']=['Anna','Zane','Jānis','Gustavs','Antons','Adrians','Melisa','Nikola','Emīlija','Sofija','Toms','Matīss']
class10a['height']=['172','185','164','184','162','164','165','167','177','184','165','180']

while stop==0:
    choice=input('Rakstiet ciparu, lai izvēlētos, ko darīt.\n\t1 - Drukāt skolēna vārdus un augstumus uz ekrāna.\n\t2 - Pievienot skolēna vārdu un augstumu.\n\t3 - Izdzēst skolēnu.\n\t4 - Apskatīt vidējo augstumu.\n')
    checkExit(choice)

    if choice=='1': #izdrukā skolēnu vārdus un augstumus
        printDict(class10a['name'], class10a['height'])

    elif choice=='2': #lietotājs var pievienot skolēna vārdu un augstumu
        name=input('Vārds: ')
        checkExit(name)
        class10a['name'].append(name)
        height=input('Augstums: ')
        checkExit(height)
        class10a['height'].append(height)

        printDict(class10a['name'], class10a['height'])
        for x in range(len(class10a['name'])):
             if x==len(class10a['name'])-1: #turpmākā darbība notiek tikai, ja x ir pēdējais priekšmets vārdnīcā jeb skolēns, kas tika pievienots
                  print('Jūs pievienojāt:\n'+class10a['name'][x]+':',class10a['height'][x])
                  print()

    elif choice=='3': #lietotājs var izņemt skolēnu no saraksta
        name=input('Vārds: ')
        checkExit(name)
        index=class10a['name'].index(name)
        name=class10a['name'].pop(index)
        height=class10a['height'].pop(index)

        
        printDict(class10a['name'], class10a['height'])
        print(name+': '+height)
        
    elif choice=='4': #aprēķina vidējo augstumu
         sum=0
         numberOfStudents=len(class10a['name'])
         for x in range(numberOfStudents):
              print(int(class10a['height'][x]))
              sum+=int(class10a['height'][x]) #pieskaita pie summas katra skolēna augstumu
         print('Vidējais skolēnu augstums ir:',round(sum/numberOfStudents,0),'cm.')