import os.path
import random
import sys

def wrongAnswer(wordInfo):
    print(f'''
FALSCH❌
          
Sehen Sie, wie richtig:

Infinitiv: {wordInfo[0]}
Präterium: {wordInfo[1]}
Perfekt: {wordInfo[2]}
Lettisch: {wordInfo[3]}''')

def openFile(filePath):
    with open(filePath, "r", encoding='utf-8') as file:
        fileContent = file.read()
        tempWordList = fileContent.split("@\n")
        return tempWordList

path = os.path.join(os.path.realpath(sys.path[0]),"words.txt")

with open(path, "a") as file: #creates a new file if one doesn't exist
    file.close()

wordList = openFile(path)

while True:
    wordList = openFile(path)
    del wordList[0]

    userChoice = input('''
Bitte schreiben Sie die entsprechende Nummer:
1 - Wörter anzeigen
2 - Teste dich selbst
3 - Neues Wort hinzufügen
''')

    if userChoice == "1":
        print('wordList is',wordList)
        for word in wordList:
            wordInfo = word.split("\n")
            print(f'''
Inf:\t{wordInfo[0]}
Prät:\t{wordInfo[1]}
Perf:\t{wordInfo[2]}
LV:\t{wordInfo[3]}''')

    if userChoice == "2":
        shuffledWordList = random.sample(wordList, len(wordList))
        for word in shuffledWordList:
            wordInfo = word.split("\n")
            print("Infinitiv:", wordInfo[0])

            userGuess = input("Präterium: ").lower()
            if userGuess != wordInfo[1]:
                wrongAnswer(wordInfo)
                continue
            userGuess = input("Perfekt: ").lower()
            if userGuess != wordInfo[2]:
                wrongAnswer(wordInfo)
                continue
            userGuess = input("Lettisch: ").lower()
            if userGuess != wordInfo[3]:
                wrongAnswer(wordInfo)
                continue

            print("\nKorrekt✔️\n")   
     
    if userChoice == "3":
        infinitive = input("Infinitiv: ").lower()
        pastSimple = input("Präterium: ").lower()
        pastPerfect = input("Perfekt: ").lower()
        latvian = input("Lettisch: ").lower()

        newWord = f"@\n{infinitive}\n{pastSimple}\n{pastPerfect}\n{latvian}"
        with open(path, 'a') as file:
            file.write(newWord)
            file.close()

    continue