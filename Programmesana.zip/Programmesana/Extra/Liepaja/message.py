import msvcrt
import time
import os
import random
import shutil

def is_float(string):
    try:
        float(string)
        return True
    except ValueError:
        return False

datubaaze = os.path.abspath("liepaja.txt")
leaderboarda_atrasanaas_vieta = os.path.abspath("leaderboard.txt")
saraksts = []
leaderboards = []

with open(datubaaze, 'r', encoding='utf-8') as file:
    split1 = file.read().split("\n")
    for x in split1:
        saraksts.append(x.split('@'))
with open(leaderboarda_atrasanaas_vieta, 'r', encoding='utf-8') as file:
    leaderboards = eval(file.read())
print(leaderboards)

def find_indices(l, value):
    return [
        index for index, item in enumerate(l)
        if item == value
    ]


def birbs(vieta, punktis): # jāievada vieta, kurā uzdevums ņemts    
    meginajumi = 5
    for x in vieta[4]:
        if x[0] == 'Atpazīsti putnus':
            print('\nUzdevums:',x[0])
            print(x[1])
            jauts = random.choice(x[2])
            print(*jauts)
            indexer = x[2].index(jauts)
            jauts_list = []
            for y in jauts:
                jauts_list.append(y)
            ans_list = []
            for y in x[3][indexer]:
                ans_list.append(y)
            print('Ievadiet burtus!')
            while True:
                burts = input(': ').lower()
                if burts in ans_list:
                    indexes = find_indices(ans_list, burts)
                    for z in indexes:
                        jauts_list[z] = burts
                    print(*jauts_list)
                else:
                    print('Burta nav vārdā!')
                    meginajumi = meginajumi-1
                    print('Atlikuši ', meginajumi, 'mēģinājumi!')
                if jauts_list == ans_list:
                    print('\nVārds atminēts!')
                    iegutie_p = punktis
                    jpunkti = iegutie_p+5
                    return jpunkti
                elif meginajumi == 0:
                    beigas()
                    print('\nNepareizi! Pareizais vārds bija: ', *ans_list)
                    break


def fishes(vieta, punktis): # jāievada vieta, kurā uzdevums ņemts
    meginajumi = 5
    for x in vieta[4]:
        if x[0] == 'Atpazīsti ezera zivis':
            print('\nUzdevums:',x[0])
            print(x[1])
            jauts = random.choice(x[2])
            print(*jauts)
            indexer = x[2].index(jauts)
            jauts_list = []
            for y in jauts:
                jauts_list.append(y)
            ans_list = []
            for y in x[3][indexer]:
                ans_list.append(y)
            print('Ievadi burtus!')
            while True:
                burts = input(': ')
                if burts in ans_list:
                    indexes = find_indices(ans_list, burts)
                    for z in indexes:
                        jauts_list[z] = burts
                    print(*jauts_list)
                else:
                    print('Burta nav vārdā!')
                    meginajumi = meginajumi-1
                    print('Atlikuši ', meginajumi, 'mēģinājumi!')
                if jauts_list == ans_list:
                    print('\nVārds atminēts!')
                    jpunkti = punktis+5
                    return jpunkti
                elif meginajumi == 0:
                    beigas()
                    print('\nNepareizi! Pareizais vārds bija: ', *ans_list)
                    break

for xxx in saraksts:
    xxx[4] = eval(xxx[4])

spele_pabeigta = False

def noteikumi():
    print('''
---------------------------------------------------------------------------------------------------------
Spēlētājam ir jāapceļo katra no Liepājas ūdenskrātuvēm un objekti tām blakus.
Pie katras vietas ir vairāki iespējami uzdevumi, vienu no tiem programma dos Jums pildīt.
Jūs varat iegūt punktus atkarībā no tā, cik reižu Jūs centāties kādu uzdevumu izpildīt:

1 reizi - 5 punkti
2 reizes - 3 puntki
3 reizes - 1 punkts

Spēles sākumā būs doti 10 bonusa punkti, kurus var iegūt ātri izpildot uzdevumu:

<10s - 3 punkti
10s-30s - 1 punkts

Tad, kad būs visas vietas apceļotas, spēle beigsies un tiks parādīta statistika par to, kā Jums izdevās.
Būs parādīts Jūsu kopējais spēlēšanas laiks un punktu daudzums, kā arī spēlētāji ar īsāko spēlēšanas laiku.
Obligāti ievērojiet lielos un mazos burtus, kā arī atstarpes!
---------------------------------------------------------------------------------------------------------
    ''')

uzdevumi = {'Kaitbords': [1,2,3], 'Makšķernieki': [4,5,6],'Atkritumu savākšana un šķirošana zilā karoga pludmalē': [7,8,9], 'Ūdens drošība': [10, 11, 12], 'Liepājas vēstures fakti': [13, 14, 15], 'Atpazīsti ezera zivis': [16,17,18], 'Atpazīsti putnus': [19,20,21], 'Ūdens motociklu sacīkstes': [22,23,24], 'Veikbords': [25,26,27]}


uzdevumi = {}
for a in saraksts:
    for b in a[4]:
        if b[0] not in uzdevumi.keys():
            uzdevumi[b[0]] = [b[1], b[2], b[3]]
def editors():
    saraksts_obj = []
    print('---------- Rediģēšana ----------\n')
    while True:
        for vietas in saraksts:    
            saraksts_obj.append(vietas[1])
        print('1 - pievienot vietu\n2 - pievienot uzdevumu\n3 - noņemt vietu\n4 - noņemt uzdevumu\n5 - rediģēt vietu\n6 - beigt rediģēšanu')
        choice = input(': ')
        if choice == '1':
            jaun_viet_krat = input('Ūdens krātuve pie kuras atrodas: ')
            jaun_viet_obj = input('Objekta nosaukums: ')
            jaun_viet_koor = input('Ievadi objekta koordinātas: ')
            jaun_viet_desc = input('Objekta apraksts: ')
            jaun_viet_uzd = []
            print('uzdevumi: \n')
            for uzdevums123 in uzdevumi:
                print(uzdevums123)
            print('Kuri uzdevumi iespējami šajā vietā: (kad visi uzdevumi ievadīti, ievadiet "beigt"): ')
            while True:
                ievad_uzd = input(': ')
                if ievad_uzd == 'beigt':
                    break
                else:
                    if ievad_uzd in uzdevumi.keys():
                        jaun_viet_uzd.append([ievad_uzd, jaun_viet_desc, uzdevumi[ievad_uzd][1],uzdevumi[ievad_uzd][2]])
                    else:
                        print('tāda uzdevuma nav.')
            saraksts.append([jaun_viet_krat, jaun_viet_obj, jaun_viet_koor, jaun_viet_desc, jaun_viet_uzd])
            print([jaun_viet_krat, jaun_viet_obj, jaun_viet_koor, jaun_viet_desc, jaun_viet_uzd])    

        elif choice == '2':
            jaun_uzd_nosauk = input('Jaunā uzdevuma nosaukums: ')
            jaun_uzd_nosac = input(f'{jaun_uzd_nosauk} nosacījumi: ')
            jaun_uzd_jaut = input("Uzdevuma jautājums: ")
            jaun_uzd_atb = input('Atbildes uz jauno uzd: ')
            uzdevumi[jaun_uzd_nosauk] = [jaun_uzd_nosac,jaun_uzd_jaut, jaun_uzd_atb]

        elif choice == '3':
            print('kuru vietu dzēst?\nvietas:')
            for lietas in saraksts_obj:
                print(lietas)
            
            vieta_del = input(': ').lower()
            if vieta_del in saraksts_obj:
                for vietas1 in saraksts:
                    if vietas1[1].lower() == vieta_del:
                        saraksts.pop(saraksts.index(vietas1))
            
            else:
                print('tāda objekta nav!')
        elif choice == '4':
            print('kuru uzdevumu noņemt?\n', )
            for uzdevums_is in uzdevumi:
                print(uzdevums_is)
            uzdevums_del = input(': ')
            if uzdevums_del in uzdevumi:
                uzdevumi.pop(uzdevums_del)
            else:
                print('\nnav tāda uzdevuma!\n')
        elif choice =='5':
            print('Kuru vietu redidģēt?\n')
            for vietas2 in saraksts_obj:
                print(vietas2)
            edit_vieta = input(': ')
            if edit_vieta in saraksts_obj:
                action = input('\n 1 - pievienot uzdevumu vietai \n 2 - noņemt uzdevumu vietai \n 3 - atcelt\n')
                if action == '1':
                    print('Kuru uzdevumu pievienot?')
                    for uzd_obj in uzdevumi:
                        print(uzd_obj)
                    choice2 = input(': ')
                    if choice2 in uzdevumi.keys():
                        for places in saraksts:
                            if edit_vieta in places:
                                obj_list_index = saraksts.index(places)


                        saraksts[obj_list_index][4].append([choice2, uzdevumi[choice2][0],uzdevumi[choice2][1],uzdevumi[choice2][2]])
                        
                    else:
                        print('Nav tāda uzdevuma!')
                elif action == '2':
                    for places in saraksts:
                            if edit_vieta in places:
                                obj_list_index = saraksts.index(places)
                    print('Kuru uzdevumu noņemt?')
                    for uzd_obj in saraksts[obj_list_index][4]:
                        print(uzd_obj[0])
                    choice3 = input(': ')
                    
                    for places2 in saraksts[obj_list_index][4]:
                        if choice3 in places2:
                            obj_list_index2 = saraksts[obj_list_index][4].index(places2)
                            saraksts[obj_list_index][4].pop(obj_list_index2)
        elif choice == '6':
            break
        elif choice == '7':
            command = input('komanda\n:')
            exec(command)
        saraksts_obj = []



def spele(ppunkti):
    jpunkti = 0
    print('\nKur Jūs dosities? (Atbildiet ar skaitli, piem., "10"):\n')
    vieta_peec_skaita = 1
    for i in saraksts:
        if i[0] == '':
            print(str(vieta_peec_skaita) + '.', i[1])
            vieta_peec_skaita += 1
        else:
            print(str(vieta_peec_skaita) + '.', i[0], '-', i[1])
            vieta_peec_skaita += 1
    while True:
        atb = input('\nAtbilde: ')
        if atb.isdigit() == True:
            atb = int(atb)
            if atb < len(saraksts)+1 and atb > 0:
                atb = atb-1
                break
            else:
                print('Ievadi vienu no atbildēm.')
                continue
        else:
            print('Ievadi tikai skaitli.')
            continue
    if saraksts[atb][0] == '':
        print('\nJūs izvēlējāties:', saraksts[atb][1])
    else:
        print('\nJūs izvēlējāties:', saraksts[atb][0], '-', saraksts[atb][1])
    print('Koordinātas:', saraksts[atb][2])
    print('Apraksts:', saraksts[atb][3])
    uzdevumi_lokaacijaa = saraksts[atb][4]
    for uzdevums in uzdevumi_lokaacijaa:
        if uzdevums[0] not in uzdevumi.keys():
            uzdevumi_lokaacijaa.remove(uzdevums)
            print(uzdevums, 'NONEMTS')
    izveeleetais_uzdevums = random.choice(uzdevumi_lokaacijaa)
    kuru_uzd_pildiis= []
    for i in range(len(izveeleetais_uzdevums[3])):
        kuru_uzd_pildiis.append(i)
    kuru_uzd_pildiis1 = random.choice(kuru_uzd_pildiis)
    uzdevuma_saksanas_laiks = time.time()
    if izveeleetais_uzdevums[0] == 'Atpazīsti ezera zivis':
        uzdevuma_saksanas_laiks = time.time()
        tgd_punkti = ppunkti
        jpunkti = fishes(saraksts[atb], tgd_punkti)
        del saraksts[atb]
        return jpunkti, uzdevuma_saksanas_laiks
    elif izveeleetais_uzdevums[0] == "Atpazīsti putnus":
        uzdevuma_saksanas_laiks = time.time()
        tgd_punkti = ppunkti
        jpunkti = birbs(saraksts[atb], tgd_punkti)
        del saraksts[atb]
        return jpunkti, uzdevuma_saksanas_laiks
    else:
        print('\nUzdevums:', izveeleetais_uzdevums[0] + '\n' + izveeleetais_uzdevums[1] + '\n')
        print(izveeleetais_uzdevums[2][kuru_uzd_pildiis1])
        meeginaajums = 0
        for i in range(3):
            atbilde = input('\nAtbilde: ')
            if atbilde == izveeleetais_uzdevums[3][kuru_uzd_pildiis1]:
                print('\nPareizi')
                if meeginaajums == 0:
                    jpunkti = ppunkti + 5
                    print('Saņēmāt 5 punktus!')
                elif meeginaajums == 1:
                    jpunkti = ppunkti + 3
                    print('Saņēmāt 3 punktus!')
                elif meeginaajums == 2:
                    jpunkti = ppunkti + 1
                    print('Saņēmāt 1 punktu!')
                print('\nJūsu tagadējie punkti:', jpunkti)
                del saraksts[atb]
                return jpunkti, uzdevuma_saksanas_laiks
            else:
                print('Nepareizi! Vēl', 3- (meeginaajums+1), 'mēģinājumi palikuši.')
                meeginaajums = meeginaajums + 1
                if meeginaajums == 3:
                    beigas()
    


def beigas():
    end = time.time()
    laiks = round(end-start, 2)
    laiks_sec = laiks
    laiks_min = laiks_sec//60
    laiks_hours = laiks_min//60
    laiks_min = laiks_min-laiks_hours*60
    laiks_sec = laiks_sec-laiks_min*60
    rez = str(int(laiks_hours)) + ':' +  str(int(laiks_min)) +':'+str(round(laiks_sec))
    gala_punkti = punkti + bonusa_punkti
    print('Gala punkti:', gala_punkti)
    print('Gala laiks:', rez)
    if len(saraksts) == 0:
        lietotaaja_vaards = input('Jūsu vārds: ')
        leaderboards.append([laiks, lietotaaja_vaards, gala_punkti])
        leaderboards.sort(key = lambda x: x[0])
        with open(leaderboarda_atrasanaas_vieta, 'w', encoding='utf-8') as file:
            file.write(str(leaderboards))
        atbild = input('Vai vēlaties apskatīt 10 labākos spēles rezultātus? (j):')
        if atbild == 'j':
                for i in range(10):
                    print(leaderboards[i][0], 'sekundes -' , leaderboards[i][1], '-', leaderboards[i][2], 'punkti')
                print('Paldies par spēlēšanu!\nJauku dienu :)')
        else:
            print('Paldies par spēlēšanu!\nJauku dienu :)')
    exit()



bonusa_punkti = 10


start = time.time()
teksts = "Brīvdienas pie Liepājas ūdeņiem 2023"


print(teksts.center(shutil.get_terminal_size().columns))
print("-----------------------------------------------------\nVeidotāji: Gatis Zlojs, Edgars Mazītis, Justs Tomsons\n-----------------------------------------------------\n")
noteikumi()
print("\nUzspiediet 'q' pogu, lai spēlētu.\nUzspiediet 'x' divreiz lai mainītu spēles sastāvu.")
while spele_pabeigta == False:
    if msvcrt.kbhit():
        if msvcrt.getch().decode() == 'q':
            punkti = 0
            while True:
                vertibas = spele(punkti)
                punkti = vertibas[0]
                uzdevuma_saksanas_laiks = vertibas[1]
                uzdevuma_beigsanas_laiks = time.time()
                uzdevums_pildisanas_laiks = uzdevuma_beigsanas_laiks - uzdevuma_saksanas_laiks
                uzd_laiks_min = uzdevums_pildisanas_laiks//60
                uzdevums_pildisanas_laiks_sec = uzdevums_pildisanas_laiks-uzd_laiks_min*60
                print('Uzdevuma pildīšanas laiks:', str(round(uzd_laiks_min)), 'min', str(round(uzdevums_pildisanas_laiks_sec)), 's')
                if uzdevums_pildisanas_laiks < 10:
                    bonusa_punkti = bonusa_punkti + 3
                    print('Jūs ieguvāt vēl 5 bonusa punktus!\nJūsu tagadējie bonusa punkti:', bonusa_punkti)
                elif uzdevums_pildisanas_laiks < 30:
                    bonusa_punkti = bonusa_punkti + 1
                    print('Jūs ieguvāt vēl 3 bonusa punktus!\nJūsu tagadējie bonusa punkti:', bonusa_punkti)
                if len(saraksts) == 0:
                    spele_pabeigta = True
                    break
            break
        elif msvcrt.getch().decode() == 'x':
           editors()
           print("\nUzspiediet 'q' pogu, lai spēlētu.\nUzspiediet 'x' divreiz lai mainītu spēles sastāvu.")
           continue
print('\nEnd game\n')
beigas()